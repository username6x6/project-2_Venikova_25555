#!/usr/bin/env python3
def main():
    print ("DB project is running!")
    return None
main()
