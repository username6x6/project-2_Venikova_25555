from prompt import prompt
import sys
from typing import Dict, Any
from utils import load_metadata, save_metadata
from core import create_table, drop_table, list_tables, help_text

META_PATH = "db_meta.json"

def parse_columns(parts: list) -> list:
    # оставляет как есть для простоты: части после команды — столбцы
    return parts

def run():
    metadata = load_metadata(META_PATH)

    print("База данных запущена. Введите команду. help для справки.")
    while True:
        try:
            user_input = input(">>> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break

        if not user_input:
            continue

        tokens = user_input.split()
        cmd = tokens[0].lower()

        if cmd == "create_table":
            if len(tokens) < 3:
                print("Некорректная команда. Ожидались имя таблицы и столбцы.")
                continue
            table_name = tokens[1]
            columns = tokens[2:]
            try:
                metadata = create_table(metadata, table_name, columns)
                save_metadata(META_PATH, metadata)
            except ValueError as ve:
                print(f"Ошибка: {ve}")

        elif cmd == "drop_table":
            if len(tokens) != 2:
                print("Некорректная команда. Ожидалось имя таблицы.")
                continue
            table_name = tokens[1]
            metadata = drop_table(metadata, table_name)
            save_metadata(META_PATH, metadata)

        elif cmd == "list_tables":
            tabs = list_tables(metadata)
            print("_tables- " + (", ".join(tabs) if tabs else ""))
        elif cmd == "help":
            print(help_text())
        elif cmd == "exit":
            break
        else:
            print(f"Некорректная функция: {cmd}. Попробуйте снова.")

    print("Выход из программы.")
